print("Geek University")
