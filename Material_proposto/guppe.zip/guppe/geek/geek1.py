
pi = 3.1456


def funcao1(a, b):
    return a + b

